package com.example.girlsshopping.products;

public class Product {
    String name;
    Integer image;

    public Product(String name, Integer image) {
        this.name = name;
        this.image = image;
    }
}
